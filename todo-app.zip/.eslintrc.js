module.exports = {
  rules: {
    'vue/multi-word-component-names': 'off',
  },
}